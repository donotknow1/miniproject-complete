package com.ars.dao;


import java.util.List;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;

public interface IARSDao {

    int cancelFlightBooking(int booking_id) throws AirlineException;
	
	public BookingBean getAllDetailsById(int uid) throws AirlineException;

	boolean adminDetailsDao(UsersBean airbean,String role) throws  AirlineException;

	List<FlightBean> getFlightDetails() throws AirlineException;
	
	List<FlightBean> flightOccupancy() throws AirlineException;

	FlightBean viewAllFlight(int fno) throws AirlineException;

	int bookFlight(BookingBean book) throws AirlineException;

	int insertFlightDetail(FlightBean fbi) throws AirlineException;
	
    public abstract FlightBean updateFlightName(int flightNo, String airline) throws AirlineException;
	
	FlightBean updateSeats(int flightNo, int firstSeats, int bussSeats) throws AirlineException;
	
	FlightBean updateCity(int flightNo, String depCity, String arrCity) throws AirlineException;
	
	FlightBean updateTime(int flightNo, String depTime, String arrTime) throws AirlineException;
	
	int  deleteFlight(String flightno) throws AirlineException;


}
