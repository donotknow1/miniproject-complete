package com.ars.service;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ars.dao.ARSDao;
import com.ars.dao.IARSDao;
import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;

public class ARSService implements IARSService {
static IARSDao idao=null;
static Scanner scan=null; 	


@Override
public int cancelFlightBooking(int booking_id) throws AirlineException{

	idao=new ARSDao();
	return idao.cancelFlightBooking(booking_id);
}


@Override
public BookingBean getAllDetailsById(int uid) throws AirlineException {
	idao=new ARSDao();
	return idao.getAllDetailsById(uid);
}


	
	@Override
	public boolean adminDetailsServ(UsersBean airbean,String role) throws AirlineException {
		
		idao=new ARSDao();
		return idao.adminDetailsDao(airbean,role);
	}


	@Override
	public List<FlightBean> getFlightDetails() throws AirlineException {
		
		idao=new ARSDao();
		return idao.getFlightDetails();
	}
	
	@Override
	public List<FlightBean> flightOccupancy() throws AirlineException {
		idao=new ARSDao();
		return idao.flightOccupancy();
	}


	@Override
	public FlightBean viewAllFlight(int fno) throws AirlineException {
		
		idao=new ARSDao();
	
		return idao.viewAllFlight(fno);
	}


	@Override
	public int bookFlight(BookingBean book) throws AirlineException {
		
		idao=new ARSDao();
		
		return idao.bookFlight(book);
	}


	@Override
	public int insertFlightDetail(FlightBean fbi) throws AirlineException {
		idao=new ARSDao();
		return idao.insertFlightDetail(fbi);
	}

	@Override
	public FlightBean updateFlightName(int flightNo, String airline) throws AirlineException {
		 idao = new ARSDao();
		return idao.updateFlightName(flightNo, airline);
	}


	@Override
	public FlightBean updateSeats(int flightNo, int firstSeats, int bussSeats) throws AirlineException {
		idao = new ARSDao();
		return idao.updateSeats(flightNo, firstSeats, bussSeats);
	}


	@Override
	public FlightBean updateCity(int flightNo, String depCity, String arrCity) throws AirlineException {
		idao = new ARSDao();
		return idao.updateCity(flightNo, depCity, arrCity);
	}


	@Override
	public FlightBean updateTime(int flightNo, String depTime, String arrTime) throws AirlineException {
		idao = new ARSDao();
		
		return  idao.updateTime(flightNo, depTime, arrTime);
	}
	
	
	@Override
	public int deleteFlight(String flightno) throws AirlineException {
		idao= new ARSDao();
		return idao.deleteFlight(flightno);
	}
	

	@Override
	public boolean validateEmailId(String email) 
	{
		
		Pattern p1=Pattern.compile("[A-Za-z0-9]{1,12}[@]{1}[gG]{1}[mM]{1}[aA]{1}[iI]{1}[lL]{1}[.]{1}[cC]{1}[oO]{1}[mM]{1}");
		Matcher m1=p1.matcher(email);
		if(!(m1.matches()))
 	   {
 		   System.out.println("email should be end from @gmail.com");
 		   return false;
 	   }
		
		return true;
	}


	@Override
	public boolean validateCreditCard(String creditCard) 
	{
	
		     Pattern p2=Pattern.compile("[1-9]{1}[0-9]{5}");
		 	Matcher m2=p2.matcher(creditCard);
		     if(!(m2.matches()))
		     {
		    	 System.out.println("credit card should be 6 digit number and should not start with 0");
		    	 return false;
		     }
		
		return true;
	}
	
	
	
	@Override
	public boolean validateFlightName(String airline) {
		//System.out.println("Enter Flight Name:");
	
		Pattern pattern1=Pattern.compile("[A-Za-z]{3,15}");
		Matcher matcher=pattern1.matcher(airline);
		if(!(matcher.matches())) {
			System.out.println("Please Enter FlightName:FirstCharacter uppercase and rest of all lowercase ");
			return false;	
		}
		else
		return true;
	}

	@Override
	public boolean validateDpCity(String depCity) {
		//System.out.println("Enter Departure City Name:");
		//String c=scan.next();
		Pattern pattern2=Pattern.compile("[A-Za-z]{3,15}");
		Matcher matcher=pattern2.matcher(depCity);
		if(!(matcher.matches())) {
			System.out.println("Please Enter DepartureCity Name:FirstCharacter uppercase and rest of all lowercase ");
			return false;
		}
		
		return true;
	}

	@Override
	public boolean validateArCity(String arrCity) {
		//System.out.println("Enter Arrival City Name:");
		//String d=scan.next();
		Pattern pattern3=Pattern.compile("[A-Za-z]{3,15}");
		Matcher matcher=pattern3.matcher(arrCity);
		if(!(matcher.matches())) {
			System.out.println("Please Enter ArrivalCity Name:FirstCharacter uppercase and rest of all lowercase ");
			return false;
		}
		
		return true;
	}

	@Override
	public boolean validateFSeats(int firstSeats) {
		//System.out.println("Enter First Class Seats:");
		//int e=scan.nextInt();
		if(firstSeats<1||firstSeats>151) {
			System.out.println("Please Enter First Class Seats: In Between 1 and 150 ");
			return false;
		}
		
		return true;
	}

	@Override
	public boolean validateFCFair(int firstFair) {
		//System.out.println("Enter First Class Seats Fair:");
		//int f=scan.nextInt();
		if(firstFair<10000||firstFair>200000) {
			System.out.println("Please Enter First Class Seats Fair: In Between 10000 and 200000 ");
			return false;
		}
		
		return true;
	}

	@Override
	public boolean validateBSeats(int bussSeat) {
		//System.out.println("Enter Business Class Seats:");
		//int g=scan.nextInt();
		if(bussSeat<1||bussSeat>151) {
			System.out.println("Please Enter Business Class Seats: In Between 1 and 150 ");
			return false;
		}
		
		return true;
	}

	@Override
	public boolean validateBCFair(int bussFair) {
		//System.out.println("Enter Business Class Seats Fair:");
		//int h=scan.nextInt();
		if(bussFair<10000||bussFair>200000) {
			System.out.println("Please Enter Business Class Seats Fair: In Between 10000 and 200000 ");
			return false;
		}
		
		return true;
	}


	
	
	
	
	
}
