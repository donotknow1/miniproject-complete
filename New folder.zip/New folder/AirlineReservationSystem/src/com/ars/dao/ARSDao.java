package com.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;
import com.ars.ui.Client;
import com.ars.util.DbUtil;

public class ARSDao implements IARSDao {

		Connection conn=null;
		
		@Override
		public int cancelFlightBooking(int booking_id) throws AirlineException{
			conn=DbUtil.getConnection();
			int status1=0;
			try {
				PreparedStatement dst=conn.prepareStatement(IQueryMapper.DELETE_QRY_BOOKING_INFO);
				dst.setInt(1, booking_id);
				status1=dst.executeUpdate();
				
			} catch (SQLException e) {
				
				throw new AirlineException("can't be deleted"+e.getMessage());
			}
			
			
			return status1;
		}

		@Override
		public BookingBean getAllDetailsById(int uid) throws AirlineException {
			conn=DbUtil.getConnection();
			BookingBean b=null;
			try {
				PreparedStatement pst = conn.prepareStatement(IQueryMapper.SELECT_QRY_BOOKING_INFO);
				pst.setInt(1, uid);
				ResultSet rs = pst.executeQuery();
				while(rs.next())
				{
					b=new BookingBean(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getInt(5),rs.getInt(6),rs.getString(7),rs.getString(8),rs.getString(9));
					
				}
				
			} catch (SQLException e) {
				System.out.println("Could not retrieve data by id"+e.getMessage());
			}
			return b;
		}

		
	
	@Override
	public boolean adminDetailsDao(UsersBean airbean,String role) throws AirlineException {
		
		conn=DbUtil.getConnection();
	
	   UsersBean ub=null;
	   String password=null;
	   String userName=null;
       String r=null;
       System.out.println(role);
		try {
		PreparedStatement retrieve=conn.prepareStatement(IQueryMapper.SELECT_QRY_USERS);
		retrieve.setString(1, airbean.getUsername());
		retrieve.setString(2, airbean.getPassword());
		retrieve.setString(3, role);
	    ResultSet status=retrieve.executeQuery();
	   
	    while(status.next()) {
	    	ub=new UsersBean(status.getString(1), status.getString(2), status.getString(3));
	    	userName=status.getString(1);
	    	password=status.getString(2);
			if(userName.equals(airbean.getUsername()) && password.equals(airbean.getPassword())) {
				
				return true;
				
			}
	    }
		}catch(SQLException e) {
			throw new AirlineException("Invalid credentials "+e.getMessage());
		}
		
		return false;
		 
	}

	@Override
	public List<FlightBean> getFlightDetails() throws AirlineException {
		
		conn=DbUtil.getConnection();
		List<FlightBean> flight=null;
		
		try {
			Statement getFlight=conn.createStatement();
			ResultSet rs1=getFlight.executeQuery(IQueryMapper.SELECT_QRY_FLIGHTINFO);
			//PreparedStatement getFlight=conn.prepareStatement(IQueryMapper.SELECT_QRY_FLIGHTINFO);
			flight=new ArrayList<>();
			FlightBean f=null;
			while(rs1.next()) {
				f=new FlightBean(rs1.getInt(1), rs1.getString(2), rs1.getString(3), rs1.getString(4), rs1.getString(5), rs1.getString(6), rs1.getString(7),rs1.getString(8), rs1.getInt(9), rs1.getInt(10),rs1.getInt(11), rs1.getInt(12)); 
			    flight.add(f);
			}
			
		} catch (SQLException e) {
			
			throw new AirlineException("Data can't be retrieved");
		}
		
		return flight;
	}

	@Override
	public FlightBean viewAllFlight(int fno) throws AirlineException {
	
		conn=DbUtil.getConnection();
		FlightBean f2=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.SELECT_QRY_FLIGHTID);
			pst.setInt(1, fno);
			ResultSet rs2=pst.executeQuery();
		/*	if(rs2!=null) {
				System.out.println("Please enter valid flight id");
			}                                                                 */
			while(rs2.next()) {
				f2=new FlightBean(rs2.getString(1),rs2.getString(2),rs2.getInt(3),rs2.getInt(4));
			}
			} catch (SQLException e) {
			throw new AirlineException(e.getMessage());
		}
		
		return f2;
	     
		
	}

	@Override
	public int bookFlight(BookingBean book) throws AirlineException {
		
		conn=DbUtil.getConnection();
		//BookingBean b1=null;
		int status=0;
		int bookingId=0;
		try {
			PreparedStatement bpst=conn.prepareStatement(IQueryMapper.INSERT_QRY_BOOKING_INFO);
			bpst.setString(1, book.getCustomerMail());
			bpst.setInt(2,book.getPassengers());
			bpst.setString(3,book.getClassType());
			bpst.setInt(4,book.getTotalFare());
			bpst.setString(5,book.getCreditCardNo());
			bpst.setString(6,book.getSrcCity());
			bpst.setString(7,book.getDestCity());
			status=bpst.executeUpdate();
			PreparedStatement bps=conn.prepareStatement(IQueryMapper.BOOKING_INFO_SEQ);
			ResultSet rs = bps.executeQuery();
			if(rs.next())
			{
				bookingId=rs.getInt(1);
			}
			
		}catch(SQLException e) {
			throw new AirlineException("can't be inserted"+e.getMessage());
		}
		//System.out.println("hai");
		return bookingId;
	}
	

	@Override
	public int insertFlightDetail(FlightBean fbi) throws AirlineException {
		conn=DbUtil.getConnection();
		//FlightBean fbi=null;
		int status=0;
		try {
			PreparedStatement bpst=conn.prepareStatement(IQueryMapper.INSERT_QRY_FLIGHT_INFO);
			bpst.setInt(1, fbi.getFlightNo());
			bpst.setString(2,fbi.getAirline());
			bpst.setString(3,fbi.getDepCity());
			bpst.setString(4,fbi.getArrCity());
			//bpst.setString(5,fbi.getDepdate());
			//bpst.setString(6,fbi.getArrDate());
			//bpst.setString(7,fbi.getDepTime());
			//bpst.setString(8,fbi.getArrTime());
			bpst.setInt(5,fbi.getFirstSeats());
			bpst.setInt(6,fbi.getFirstFair());
			bpst.setInt(7,fbi.getBussSeats());
			bpst.setInt(8,fbi.getBussFair());
			status=bpst.executeUpdate();
		}catch(Exception e) {
			throw new AirlineException("can't be inserted"+e.getMessage());
		}
		
		
		return status;
	}

	
	@Override
	public FlightBean updateFlightName(int flightNo, String airline) throws AirlineException {
		conn = DbUtil.getConnection();
		FlightBean fb = null;
		int status = 0;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_QRY_FLIGHT_NAME);
			pst.setString(1, airline);
			pst.setInt(2, flightNo);
			int rs=pst.executeUpdate();
			
		}
		catch(SQLException e) {
			throw new AirlineException("can't be updated" +e.getMessage());
		}
		return fb;
		
	}

	@Override
	public FlightBean updateSeats(int flightNo, int firstSeats, int bussSeats) throws AirlineException {
		conn = DbUtil.getConnection();
		FlightBean fb = null;
		int status = 0;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_QRY_FLIGHT_SEATS);
			pst.setInt(1,firstSeats);
			pst.setInt(2,bussSeats);
			pst.setInt(3, flightNo);
			status=pst.executeUpdate();
		} catch (SQLException e) {
			throw new AirlineException("can't be updated" +e.getMessage());
		}
		return fb;
		
	}

	@Override
	public FlightBean updateCity(int flightNo, String depCity, String arrCity) throws AirlineException {
		conn = DbUtil.getConnection();
		FlightBean fb = null;
		int status = 0;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_QRY_FLIGHT_CITIES);
			pst.setString(1, depCity);
			pst.setString(2, arrCity);
			pst.setInt(3, flightNo);
			status=pst.executeUpdate();
			
		} catch (SQLException e) {
			throw new AirlineException("can't be updated" +e.getMessage());
		}
		return fb;
		
	}

	@Override
	public FlightBean updateTime(int flightNo, String depTime, String arrTime) throws AirlineException {
		conn = DbUtil.getConnection();
		FlightBean fb = null;
		int status = 0;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_QRY_FLIGHT_TIME);
			pst.setString(1, depTime);
			pst.setString(2, arrTime);
			pst.setInt(3, flightNo);
			
			
			status=pst.executeUpdate();
			
		} catch (SQLException e) {
			throw new AirlineException("can't be updated" +e.getMessage());
		}
		return fb;
		
	}

	
	@Override
	public int  deleteFlight(String flightno) throws AirlineException {
		
		conn = DbUtil.getConnection();
		int status2=0;
		try {
			;
			PreparedStatement dft= conn.prepareStatement(IQueryMapper.DELETE_FLIGHT);
			dft.setString(1, flightno);
			//int a=Integer.parseInt(status2);
			status2= dft.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println(e);
		}
		return status2;
		
	}
	
	
}
