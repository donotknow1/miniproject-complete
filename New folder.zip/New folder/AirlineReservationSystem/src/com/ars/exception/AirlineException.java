package com.ars.exception;

public class AirlineException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AirlineException(String msg) {
		
		super(msg);
	
	}

	public AirlineException() {
		super();

	}

	
	
	
	
	
	
	
	
}
