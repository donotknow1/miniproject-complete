package com.ars.service;


import java.util.List;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;

public interface IARSService {
	
	int cancelFlightBooking(int booking_id) throws AirlineException;
	
	public BookingBean getAllDetailsById(int uid) throws AirlineException;

	boolean adminDetailsServ(UsersBean airbean,String role) throws AirlineException;

	List<FlightBean> getFlightDetails() throws AirlineException;

	FlightBean viewAllFlight(int fno) throws AirlineException;

	int bookFlight(BookingBean bean) throws AirlineException;

	int insertFlightDetail(FlightBean fbi) throws AirlineException;
	
	public abstract FlightBean updateFlightName(int flightNo, String airline) throws AirlineException;

	FlightBean updateSeats(int flightNo, int firstSeats, int bussSeats) throws AirlineException;

	FlightBean updateCity(int flightNo, String depCity, String arrCity) throws AirlineException;

	FlightBean updateTime(int flightNo, String depTime, String arrTime) throws AirlineException;
	
	int deleteFlight(String flightno) throws AirlineException;

	public abstract boolean validateFlightName(String airline);

	boolean validateDpCity(String depCity);

	boolean validateArCity(String arrCity);

	boolean validateFSeats(int firstSeats);

	boolean validateFCFair(int firstFair);

	boolean validateBSeats(int bussSeat);

	boolean validateBCFair(int bussFair);

	public boolean validateEmailId(String email);
	
	public boolean validateCreditCard(String creditCard);
}
