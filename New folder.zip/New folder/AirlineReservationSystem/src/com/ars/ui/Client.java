package com.ars.ui;

import java.util.List;

import java.util.Random;
import java.util.Scanner;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;
import com.ars.service.ARSService;
import com.ars.service.IARSService;

public class Client {

	
	static Scanner scan=null;
	static UsersBean airbean=null;
	static BookingBean book=null;
	
	static IARSService iars=null;
	
	
	public Client() {
		super();
		iars=new ARSService();
		
	}


	public static void main(String[] args){
		Client obj=new Client();
		scan=new Scanner(System.in);
		
		System.out.println("-------------WELCOME--------------------");
		System.out.println("1.GET FLIGHT INFORMATION");
		System.out.println("2.USER LOGIN");
		System.out.println("4.EXIT");
		
		System.out.println("Choose your option");
		int option=scan.nextInt();
		
		switch(option) {
		
		case 1:
			try {
			obj.viewFlightDetails();
			}catch(AirlineException e) {
				System.out.println(e.getMessage());
			}
			FlightBean fbean=null;
			System.out.println("If you want to continue with booking");
			do {
			System.out.println("Please Enter Valid flight number:");
			int fno=scan.nextInt();
			try {
				fbean=validateFlight(fno);
	        }
			catch(AirlineException e) {
	        	System.out.println(e.getMessage());
	        }
	        }while(fbean==null);
			
			
		/*	List<FlightBean> flightList=null;
			
			try {
				flightList=getFlightDetails();
			}
			catch(AirlineException e) {
				System.out.println(e.getMessage());
			}
			
			for(FlightBean fb:flightList) {
				System.out.println(fb);
			}
				System.out.println("If you want to continue with booking");
				System.out.println("Please Enter flight number:");
				int fno=scan.nextInt();
				FlightBean fbean=null;
				try {
				fbean=validateFlight(fno);
            }catch(AirlineException e) {
            	System.out.println(e.getMessage());
            }         */
			System.out.println("1.Confirm booking");
			System.out.println("2.view Booking");
			System.out.println("3.cancel Booking");
			System.out.println("4.Exit");
				int opt=scan.nextInt();
				Random rand = new Random();
				int n = rand.nextInt(50) + 1;
				String classType=null;
				int totalF = 0;
				switch(opt) {
				case 1:
					String email=null;
					do{
					System.out.println("Enter email id :");
				    email=scan.next();
					}while(iars.validateEmailId(email)==false);
				       int pass=0;
				    
				       //Enter email
				       
				       //enter passengers
				       do
				       {
				    	   System.out.println("Enter number of passengers");
				            pass=scan.nextInt();
				       if(pass<=0)
				       {
				    	   System.out.println("passengers should be greater than 0");
				       }
				      
				    	   
				       }while(pass<=0);
				       
				       
				       //choose class
				       System.out.println("1.First class");
				       System.out.println("2.Business class");
				       int Type=scan.nextInt();
				       if(Type==1) 
				       {
				          classType="firstclass";
					      int firstFare=fbean.getFirstFair();
					      totalF=pass*firstFare;					
					     }
				       else if(Type==2)
				          {
					        classType="bussclass";
					        int bussFare=fbean.getBussFair();
					        totalF=pass*bussFare;
				           }
				       else 
				          {
					         System.out.println("please enter class type correctly...");
				           }
				        //seat number is balance
				       
				       //Enter creditcard 
				       String creditCard=null;
				       do {
				       System.out.println("Enter credit card number :");
				       creditCard=scan.next();
				       } while(iars.validateCreditCard(creditCard)==false);
			
				     book=new BookingBean(email, pass, classType, totalF,n, creditCard, fbean.getDepCity(), fbean.getArrCity());
			
				     
			         int val=0;
			         
			         
			           try {
				          val=bookFlight(book);
			                }catch(AirlineException e) 
			            {
				           System.out.println("cannot book your details"+e.getMessage());
			             }
			            if(val>0)
			            {
		
			            System.out.println(" booking is confirmed and your booking id is: "+val );
			         }
			         else
			         {
			        	 System.out.println("try again");
			         }
			           break;
				case 2:
	    		     System.out.println("Enter your Booking id");
	    		     int uid=scan.nextInt();
	    		     BookingBean finalObj=null;
	    		     try
	    		      {
	    			   finalObj=getDetailsById(uid);	
	    		      }
	    		     catch(AirlineException e)
			    		{
			    			System.out.println("cannot get details by Id" +e.getMessage());
			    		}
			    	 System.out.println("youe Booking Details are"+finalObj);
			    	 break;
   		  
   		   
	           
   	case 3:
	    		    System.out.println("Enter your booking id");
	    		    int booking_id=scan.nextInt();
	    		    int cancel=0;
	    		    try {
	    		    	cancel=cancelBookingId(booking_id);
	    		    	
	    		         }catch(AirlineException e)
	    		         {
	    		    	   System.out.println(e.getMessage());
	    		         }
				    System.out.println("your booking is cancelled"+cancel);
				   
	    		    break;
   		   
   	case 4:
   		        System.out.println("Thank you..visit again....");
   		        System.exit(0);
	 }
	    
break;
	//end of user switch case		
		case 2:
			System.out.println("role: 1.Executive 2.Admin");
			String role=scan.next();  
			System.out.println("ENTER YOUR USERNAME");
			String username=scan.next();
			System.out.println("ENTER YOUR PASSWORD");
			String password=scan.next();
			      
			
		
			if(role.equals("admin")) {
				UsersBean airbean=new UsersBean(username, password,role);
			try {
				if(obj.adminDetailsServ(airbean, role)) {
							System.out.println("1.view flight schedule");
							System.out.println("2.update flight schedule");
							System.out.println("3.Delete flight schedule");
							System.out.println("4.Insert Flight details");
						

						System.out.println("Enter your option");
						int choose=scan.nextInt();
						switch(choose) {
						
						case 1:
							try {
								obj.viewFlightDetails();
							} catch (AirlineException e2) {
								
								System.out.println(e2.getMessage());
							}
							break;
						case 2:
							//update flight schedule updateFlightDetails();  
							int choice=0;
							
							System.out.println("1.updating flight name");
							System.out.println("2.updating seats");
							System.out.println("3.updating source and destination cities");
							System.out.println("4.updating destination and arrival time");
							System.out.println("enter your option");
							int option1=scan.nextInt();
							
							switch(option1) {
							case 1:
								
								System.out.println("enter flight no");
								int flightno = scan.nextInt();
								System.out.println("enter flight name to be updated");
								String flightname = scan.next();
								try {
									updateFlightName(flightno,flightname);
									
								}
								catch(AirlineException ae) {
									System.out.println(ae.getMessage());
								}
								break;
								
							case 2:
								System.out.println("enter flight no");
								int flightno1 = scan.nextInt();
								System.out.println("enter firstseats to be updated");
								int firstSeats = scan.nextInt();
								System.out.println("enter bussiness seats to be updated");
								int bussSeats = scan.nextInt();
								try {
									updateSeats(flightno1, firstSeats, bussSeats);
									}
							    catch(AirlineException ae) {
								System.out.println(ae.getMessage());
							    }
								break;
							case 3:
								System.out.println("enter flight no");
								int flightno2 = scan.nextInt();
								System.out.println("enter departure city to be updated");
								String depCity = scan.next();
								System.out.println("enter arrival city to be updated");
								String arrCity = scan.next();
								try {
									updateCity(flightno2, depCity, arrCity);
								}
								 catch(AirlineException ae) {
										System.out.println(ae.getMessage());
						        }
								break;
							case 4:
								System.out.println("enter flight no");
								int flightno3 = scan.nextInt();
								System.out.println("enter departure time to be updated");
								String depTime = scan.next();
								System.out.println("enter arrival time to be updated");
								String arrTime = scan.next();
								try {
									updateTime(flightno3, depTime, arrTime);
									
								}
								catch(AirlineException ae) {
									System.out.println(ae.getMessage());
								}
								break;
							}
							break;
						case 3:
							//delete flight schedule  deleteFlightDetails();

							System.out.println("please enter THE FLIGHTID to delete the flightdetails");
							String flightno = scan.next();
							int res=0;
							if(res>0)
						   try
							{
						       res= deleteflightdetails(flightno);
						       System.out.println(" your flight details are deleted");
							}catch(AirlineException e)
							{
								System.out.println(e.getMessage());
							}
						   else {
							System.out.println("your flight details not deleted "+res);
							}
						
							break;
						case 4:
							//insert flight Details  insertFlightDetails();

					    /*	String name;
					    	do {
					    	System.out.println("Enter Asset name :");
					    	name=scan.next();
					    	}while(ias.validateName(name)==false);*/
							System.out.println("Enter Flight Number: ");
							int flightNo=scan.nextInt();
							String airline;
							do {
							System.out.println("Enter airline :");
							airline=scan.next();
							}while(iars.validateFlightName(airline)==false);
							String depCity;
							do {
							System.out.println("Enter Depart City:");
							depCity=scan.next();
							}while(iars.validateDpCity(depCity)==false);
							String arrCity;
							do {
							System.out.println("Enter Arrival City:");
							arrCity=scan.next();
							}while(iars.validateArCity(arrCity)==false);
							int firstSeats;
							do {
							System.out.println("Enter Available FistClass Seats:");
							firstSeats=scan.nextInt();
							}while(iars.validateFSeats(firstSeats)==false);
							int firstFair;
							do{
						    System.out.println("Enter FirstClass Seat Fair:");
						    firstFair=scan.nextInt();
							}while(iars.validateFCFair(firstFair)==false);
							int bussSeats;
							do {
							System.out.println("Enter Bussiness Seats:");
							bussSeats=scan.nextInt();
							}while(iars.validateBSeats(bussSeats)==false);
							int bussFair;
							do {
							System.out.println("Enter Bussiness Fair:");
							bussFair=scan.nextInt();
							}while(iars.validateBCFair(bussFair)==false);
							
							  
							FlightBean fbi=new FlightBean(flightNo,airline,depCity,arrCity,firstSeats, firstFair,bussSeats,bussFair);
							int insertF=0;
							try {
								insertF=insertFlightDetails(fbi);
							}catch(AirlineException e1) {
								System.out.println(e1.getMessage());
							}
						
							System.out.println(insertF+" Flight details are updated");     
							
							try {
								insertFlightDetails(fbi);
							} catch (AirlineException e) {
								System.out.println("Data Can't be inserted"+e.getMessage());
							}
							
							break;
						
						     }
						}
			} catch (AirlineException e) {
				System.out.println(e.getMessage());
			}
		}		 
			
	}
		

	}
				
		

	private static BookingBean getDetailsById(int uid) throws AirlineException {
		iars=new ARSService();
		return iars.getAllDetailsById(uid);
	}





	private static int cancelBookingId(int booking_id) throws AirlineException 
	{
		iars=new ARSService();
		return iars.cancelFlightBooking(booking_id);
	}

		
	
		
	
	private static int insertFlightDetails(FlightBean fbi) throws AirlineException {
		
		int result=iars.insertFlightDetail(fbi);
		return result;

	}

	public static List<FlightBean> getFlightDetails() throws AirlineException
	{
		return iars.getFlightDetails();
	}
		
	

	public boolean adminDetailsServ(UsersBean airbean,String role) throws AirlineException {
		
		return iars.adminDetailsServ(airbean,role);
	}
	
	public static FlightBean validateFlight(int fno) throws AirlineException {
		
		return iars.viewAllFlight(fno);
	}
	
	
	public static int bookFlight(BookingBean book) throws AirlineException {
		
		
		return iars.bookFlight(book);
	}
	
	
	public void viewFlightDetails() throws AirlineException{
		
		List<FlightBean> flightList=null;
		
		try {
			flightList=getFlightDetails();
		}
		catch(AirlineException e) {
			System.out.println(e.getMessage());
		}
		
		for(FlightBean fb:flightList) {
			System.out.println(fb);
		}
			
		
	}
	
	public static FlightBean updateFlightName(int flightNo,String airline) throws AirlineException {
		return iars.updateFlightName(flightNo, airline);
		
		
	}
	public static FlightBean updateTime(int flightNo,String depTime,String arrTime) throws AirlineException {
		
		return iars.updateTime(flightNo, depTime, arrTime);
		
	}
	public static FlightBean updateSeats(int flightNo,int firstSeats,int bussSeats) throws AirlineException {

		return iars.updateSeats(flightNo, firstSeats, bussSeats);
		
	}
	public static FlightBean updateCity(int flightNo,String depCity,String arrCity) throws AirlineException {

		return iars.updateCity(flightNo, depCity, arrCity);
		
	}
	
public static int  deleteflightdetails(String flightno) throws AirlineException {
		
		return iars.deleteFlight(flightno);
		
		
	}

}
